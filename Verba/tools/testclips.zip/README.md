Test clips for the "Speech models" workflow. Synthetic voices (Piper hi_IN) reading
Indian-accented English, Hinglish and Hindi sentences; `refs.json` holds what each
clip should transcribe to. Used only on GitHub to compare models; not part of the app.
